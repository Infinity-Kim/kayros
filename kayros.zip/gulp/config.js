module.exports = [
    './gulp/tasks/html',
    './gulp/tasks/scss',
    './gulp/tasks/fonts',
    './gulp/tasks/img',
    './gulp/tasks/webp',
    './gulp/tasks/clean-img',
    './gulp/tasks/clean-fonts',
    './gulp/tasks/serve'
];